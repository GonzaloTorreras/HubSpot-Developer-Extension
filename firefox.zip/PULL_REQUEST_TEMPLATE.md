Your checklist for this pull request
🚨Please review the guidelines for contributing to this repository.

[] Make sure you are requesting to pull a topic/feature/bugfix branch (right side). Do not pull request to Master please.(when in doubt request Develop branch)
[] Test to make sure your feature/bugfix doesn't break other features ;)
[] Write a meaningful description of what your changes are.
[] Wait patiently and celebrate, you've submitted changes to the extension!

Description
Please describe your pull request.

<3 Thank you!
